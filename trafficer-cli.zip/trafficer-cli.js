const ui = require('./src/ui');
ui.start();