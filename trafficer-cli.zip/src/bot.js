const mineflayer = require('mineflayer');

let bot;

function startBot(log) {
  bot = mineflayer.createBot({
    host: 'localhost',
    port: 25565,
    username: 'TrafficerBot'
  });

  bot.on('chat', (username, message) => {
    if (username !== bot.username) {
      log.add(`<${username}> ${message}`);
    }
  });

  bot.on('login', () => log.add('[Bot] Đã đăng nhập thành công.'));
  bot.on('end', () => log.add('[Bot] Kết nối đã đóng.'));
  bot.on('error', err => log.add(`[Bot Error] ${err.message}`));
}

function sendMessage(text) {
  if (bot && bot.chat) {
    bot.chat(text);
  }
}

module.exports = { startBot, sendMessage };