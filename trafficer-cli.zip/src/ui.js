const blessed = require('blessed');
const bot = require('./bot');

function start() {
  const screen = blessed.screen({
    smartCSR: true,
    title: 'TrafficerMC CLI',
    fullUnicode: true
  });

  const log = blessed.log({
    parent: screen,
    top: 0,
    left: 0,
    width: '100%',
    height: '90%',
    label: ' Minecraft Bot Log ',
    border: 'line',
    scrollable: true,
    alwaysScroll: true,
    scrollbar: {
      ch: ' ',
      inverse: true
    },
    style: {
      fg: 'white',
      bg: 'black',
      border: { fg: '#f0f0f0' },
      scrollbar: { bg: 'gray' }
    }
  });

  const input = blessed.textbox({
    parent: screen,
    bottom: 0,
    left: 0,
    height: '10%',
    width: '100%',
    inputOnFocus: true,
    border: 'line',
    label: ' Chat / Command ',
    style: {
      fg: 'white',
      bg: 'black',
      border: { fg: '#f0f0f0' }
    }
  });

  input.on('submit', text => {
    if (text.trim() !== '') {
      bot.sendMessage(text.trim());
      log.add(`> ${text}`);
    }
    input.clearValue();
    screen.render();
  });

  screen.key(['C-c', 'q'], () => process.exit(0));
  screen.render();
  input.focus();

  bot.startBot(log);
}

module.exports = { start };